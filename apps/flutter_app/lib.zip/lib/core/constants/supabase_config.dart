static const String supabaseUrl = 'https://vtpusrpxucshpllclayz.supabase.co';
static const String supabaseAnonKey = 'sb_publishable_ow6cODyxsvghdCkOcSE0YA_9qXpAMqo';